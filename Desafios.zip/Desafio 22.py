#Crie um programa que leia o nome completo de uma pessoa e mostre:
#O nome com todas as letras maiúsculas e minúsculas.
#Quantas letras ao todo (sem considerar espaços).
#Quantas letras tem o primeiro nome.

nome = input('Digite seu nome: ')
tamanho = nome.split()
n1 = nome.upper()
n2 = nome.lower()
n3 = len(nome.strip())
n4 = len(tamanho[0])
print('{}\n{}\n{}\n{}'.format(n1,n2,n3,n4))
