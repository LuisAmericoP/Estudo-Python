# Faça um algoritimo que leia o salario de um funcionario e mostre 
# seu novo salario com 15% de aumento

s = float(input('Informe seu salario: '))
n = s * 0.15
a = s + n
print("Seu novo salario será {:.2f}".format(a))
