# Escreva um programa que leia um valor em metros e o exiba convertido em centimetros e milimetros

n = int(input('Me informe uma medida em metros: '))
c = n * 100
m = n * 1000
print('{} metros equivale a {} centimetros e {} milimetros'.format(n,c,m))
