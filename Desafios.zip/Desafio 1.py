dia = input('Qual o dia que você nasceu ?')
mes = input('Qual o mês que você nasceu ?')
ano = input('Qual o ano que você nasceu ?')
print(dia,mes,ano)