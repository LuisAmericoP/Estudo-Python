# Crie um algoritimo que leia um numero e mostre o seu dobro, triplo e raiz quadrada

n = int(input('Digite um numero: '))
d = n * 2
t = n * 3
r = n ** (1/2)
print('O dobro do numero {} é {}, o triplo {}, e sua raiz quadrada {}'. format(n,d,t,r))
