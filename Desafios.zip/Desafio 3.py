#Crie um programa que leia dois numeros e mostre a soma entre eles
n1 = int(input('Digite um numero '))
n2 = int(input('Digite outro numero '))
s = n1 + n2
print('A soma ente {} e {} é: {}'.format(n1,n2,s))
