# O mesmo professor do desafio anterior quer sortear a ordem de apresentação de trabalhos dos alunos
# Faça um programa que leia o nome dos quatro alunos e mostre a ordem sorteada 

from random import choice
a1 = str(input('Digite o aluno 1: '))
a2 = str(input('Digite o aluno 2: '))
a3 = str(input('Digite o aluno 3: '))
a4 = str(input('Digite o aluno 4: '))
lista = [a1, a2, a3, a4]
ap1 = choice(lista)
ap2 = choice(lista)
ap3 = choice(lista)
ap4 = choice(lista)
print('A ordem sorteada é {}, {}, {}, {}'.format(ap1,ap2,ap3,ap4))

#Outro modo
#import random
#nome1 = str(input('Digite o primeiro nome: '))
#nome2 = str(input('Digiteo segundo nome: '))
#nome3 = str(input('Digite o terceiro nome: '))
#nome4 = str(input('Digite o quarto nome: '))
#lista = [nome1,nome2,nome3,nome4]
#random.shuffle(lista) #shuffle significa embaralhar algo
#print(lista)