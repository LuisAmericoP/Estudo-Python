n1 = int(input('Digite um  numero'))
n2 = int(input('Digite outro numero'))
r = (n1 + n2)
print('A soma entre os numeros são: {}'.format(r))