'''
Desenvolva um programa que pergunte a distancia de uma viagem em Km.
Calcule o preço da passagem, cobrando R$ 0,50 po Km para viagens de até
200Km e R$0,45 para viagens mais longas
'''

d = float(input('Qual é a distancia da viagem: '))
if d <= 200:
    p = d * 0.5
else:
    p = d * 0.45
print('O preço da passagem é de R${}'.format(p))

'''
Outro método 
d = float(input('Qual é a distancia da viagem: '))
p = d * 0.5 if d <= 200 else d * 0.45
print('O preço da passagem é de R${}'.format(p))
'''