# Crie um programa que leia quanto dinheiro uma pessoa tem na carteira e mostre quantos dolares ela pode comprar
# considerar 1 dolar = 3.27 reais

r = float(input('Quantos Reais você tem ? '))
d = r / 3.27
print('Você pode comprar {:.2f} dólares'.format(d))
