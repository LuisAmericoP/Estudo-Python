# Faça um programa que leia o comprimento do cateto oposto e 
# do cateto adjacente de um triangulo  retangulo, calcule e mostre o comprimento da hipotenusa

#Forma simplificada
from math import hypot
co = float(input('Comprimento do cateto oposto: '))
ca = float(input('Comprimento do cateto adjacente: '))
hi = hypot(co,ca)
print('A hipotenusa vai medir {:.2f}'.format(hi))

#Forma sem import
#co = float(input('Comprimento do cateto oposto: '))
#ca = float(input('Comprimento do cateto adjacente: '))
#hi = (co ** 2 + ca ** 2) ** (1/2)
#print('A hipotenusa vai medir {:.2f}'.format(hi))

#Forma sem importar direto o hypot
#import math
#co = float(input('Comprimento do cateto oposto: '))
#ca = float(input('Comprimento do cateto adjacente: '))
#hi = math.hypot(co,ca)
#print('A hipotenusa vai medir {:.2f}'.format(hi))
