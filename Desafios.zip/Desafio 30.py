'''
Crie um programa que leia um numero inteiro e mostre na tela
se ele é IMPAR ou PAR
'''

n = int(input('Digite um numero: '))
r = n % 2
if r == 0:
    print('O numero {} é PAR'.format(n))
else:
    print('O numero {} é IMPAR'.format(n))
