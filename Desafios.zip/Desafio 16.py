# Crie um programa que leia um numero real qualquer pelo teclado e mostre na tela a sua posição inteira
# exemplo: digite o numero: 6.127, o numero 6.127 tem a parte inteira 6

from math import floor
num = float(input('Digite um numero quebrado: '))
print('A parte inteira do {} é {}'.format(num,floor(num)))
