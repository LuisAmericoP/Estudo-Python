#Escreva um programa que pergunte a quantidade de Km percorridos 
#por um carro alugado e a quantidade de dias pelos quais ele foi 
#alugado. Calcule o preço a pagar, sabendo que o carro custa R$60 por dia 
#e R$0,15 por Km rodado.

km = float(input('Quantos KM você percorreu com o carro: '))
dia = int(input('Quantos dias ficou com o carro: '))
kmp = km * 0.15
diap = dia * 60
print('Você pagará {}R$ pelos dia \nE {}R$ pelo Km rodados \nNo total de {}R$'.format(diap,kmp,diap+kmp))
