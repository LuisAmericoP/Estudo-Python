'''
Desenvolva um programa que leia o comprimento de três retas e diga
ao usuario se elas podem ou não formar um triangulo
'''

n1 = float(input('Primeira reta: '))
n2 = float(input('Segunda reta: '))
n3 = float(input('Terceira reta: '))
if n1 < n2 + n3 and n2 < n1+ n3 and n3 < n1+ n2 :
    print('As retas podem formar um triangulo')
else:
    print('As retas não podem formar um triangulo')
