# Faça um algoritimo que leia o preço de um produto
# e mostre seu novo preço com 5% de desconto

p = float(input('Qual é o valor do produto: '))
d = (p * 0.05)
dp = p - d
print('O valor do produto é {} e recebeu {} de desconto, você pagará {}'.format(p,d,dp))
