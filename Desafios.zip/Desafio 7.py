# Desenvolva um programa que leia as duas notas de um aluno, calcule e mostre sua média

aluno1 = int(input('Digite sua primeira nota: '))
aluno2 = int(input('Digite sua segunda nota: '))
print('Sua média é {}'.format((aluno1+aluno2)/2))
