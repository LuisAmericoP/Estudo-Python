# Faça um programa em Python que abra e reproduza um audio de um arquivo MP3

#import playsound 
#playsound.playsound('ex021.mp3')
