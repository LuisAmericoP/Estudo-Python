# Faça um programa que lei a altura e largura de uma parede em metros
# calcule sua area e a quantidade de tinta necessaria para pinta-la
# sabendo que cada litro pinta 2m²

a = int(input('Qual a altura da parede: '))
l = int(input('Qual a largura da parede: '))
area = a * l
p = area / 2
print('Sua paretem tem {} de área e será necessario {:.2f} litros de tinta'.format(area,p))
