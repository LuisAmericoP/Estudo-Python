# Um professor quer sortear um dos seus quatro alunos para apagar o quadro
# Faça um programa que ajude ele, lendo o nome deles e escrevendo o nome do escolhido

from random import choice
a1 = input('Digite o aluno 1: ')
a2 = input('Digite o aluno 2: ')
a3 = input('Digite o aluno 3: ')
a4 = input('Digite o aluno 4: ')
lista = [a1, a2, a3, a4]
esc = choice(lista)
print('O aluno(a) escolhido(a) foi {}'.format(esc))
