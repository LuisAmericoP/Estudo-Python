#Escreva um programa que converta uma temperatura digitando em 
#graus Celsius e converta para graus Fahrenheit.

gcel = float(input('Quantos graus Celsius está fazendo: '))
gfar = (gcel * 9/5) + 32
print('A temperatura em Fahrenheit é, {} °F'.format(gfar))
