#Faça um programa que leia um nuemro inteiro e mostre na tela o seu sucessor e antecessor

n = int(input('Escreva um numero: '))
s = n + 1
a = n - 1
print('O sucessor do {} é {}, e o antecessor é {}'.format(n, s, a))
