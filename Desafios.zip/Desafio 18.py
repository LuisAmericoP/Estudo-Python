# Faça um programa que leia um angulo qualquer 
# e mostra na tela o valor do seno, cosseno e tangente desse angulo

import math
an = float(input('Escreva um angulo qualquer: '))
seno = math.sin(math.radians(an))
coss = math.cos(math.radians(an))
tang = math.tan(math.radians(an))
print('O seno é {:.2f}\nO cosseno é {:.2f}\nA tangente é {:.2f}'.format(seno,coss,tang))

#math.radians para colocar na função correta
