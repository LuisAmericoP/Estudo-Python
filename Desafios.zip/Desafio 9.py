# faça um programa que leia um numero inteiro qualquer e mostre na tela sua tabuada

n = int(input('Digite um numero para montar sua tabuada: '))
for i in range(1, 11):
    print('{} x {} = {}'.format(n,i,i*n))
