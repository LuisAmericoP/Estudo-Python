'''
Escreva um programa que leia a velocidade de um carro
Se ele ultrapassar 80Km/h, mostre uma mensagem dizendo que ele foi multado.
A multa vai custar R$ 7,00 por cada km acima do limite
'''

velocida = float(input('Qual é a velcidade do Carro: '))
if velocida > 80: 
    print('MULTADO! Você excedeu o limite de velocidade de 80 Km/h')
    multa = (velocida - 80) * 7
    print('Sua Multa foi de R$ {}'.format(multa))
else:
    print('PARABENS! Você esta andando corretamente')
print('Tenha um Bom dia')
