'''
Escreva um programa que pergunte o salario de um funcionario e 
calcule o valor de seu aumento
Para salario superiores a 1.250,00, calcule um aumento de 10%
Para salario inferior ou igauis, o aumento é de 15%
'''

s = float(input('Qual é o seu salario: '))
if s <= 1250:
    n = s + (s * 15 / 100)
else:
    n = s + (s * 10 / 100)
print('Seu novo salrio sera de {}'.format(n))
